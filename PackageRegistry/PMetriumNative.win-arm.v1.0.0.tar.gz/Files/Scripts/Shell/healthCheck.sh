#!/usr/bin/env sh

echo "Ready!"